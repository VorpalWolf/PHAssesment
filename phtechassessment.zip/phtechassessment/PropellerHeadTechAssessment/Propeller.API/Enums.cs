﻿namespace Propeller.API
{
    public enum UserProfile
    {
        Regular = 1,
        Power = 98,
        Admin = 99
    }
}
