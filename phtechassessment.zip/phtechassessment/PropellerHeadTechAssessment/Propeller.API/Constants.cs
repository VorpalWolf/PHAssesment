﻿namespace Propeller.API
{
    public static class Constants
    {
        public const string LocaleClaim = "locale";
        public const string ProfileClaim = "profile";
        public const string NameClaim = "sub";
    }
}
