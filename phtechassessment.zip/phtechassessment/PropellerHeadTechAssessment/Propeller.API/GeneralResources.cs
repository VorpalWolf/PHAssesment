﻿// NOTE: See note regarding the use of namespaces for this kind of class in Program
namespace Propeller.API.Resources
{
    public class GeneralResources
    {
    }
}
